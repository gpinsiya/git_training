$(document).ready(function(){
    alert($("p").text());
    });