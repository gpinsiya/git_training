$(document).ready(function()
{
  //for table row
  $("tr:even").css("background-color", "#808080");
  $("tr:odd").css("background-color", "	#20B2AA");

});