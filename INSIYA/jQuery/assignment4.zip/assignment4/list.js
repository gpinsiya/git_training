$(document).ready(function()
{
	$("ul li:nth-child(3)").css("background-color","#808080");
	$("ul li:gt(0)").css("background-color","#20B2AA");
	$("ul li:lt(2)").css("background-color","#808080");
}); 