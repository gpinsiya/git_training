var prompt=prompt("Please enter your name","");0<prompt.length&&(alert("Hi ! "+prompt),document.getElementById("image").src="../images/happySmiley.png");
