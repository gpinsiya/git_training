alert("'Hi !  Insiya'");
function value(){
    
	var a=document.getElementById("value");
	a.src="./images/dontntntnt.png";
}