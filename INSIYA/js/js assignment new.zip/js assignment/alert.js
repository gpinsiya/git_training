alert("'Hi !  Insiya'");
var a=document.getElementById("image");
a.src="./images/dontntntnt.png";
